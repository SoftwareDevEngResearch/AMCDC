# Flags
capture = False # Continuous capture
fission = False # Implicit fission production

# Weight Roulette
wgt_roulette = 0.0 # Threshold
wgt_survive  = 1.0
